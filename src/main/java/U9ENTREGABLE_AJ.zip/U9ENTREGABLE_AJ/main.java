package U9ENTREGABLE_AJ;

public class main {
    public static void main(String[] args) {

        Consultas consultas = new Consultas();

        //Hemos estado mirando y no logramos encontrar el porque no funciona

        //consultas.filtroprecio();

        //consultas.infopagos();

        consultas.informecategoria();

        Transacciones t1 = new Transacciones();

        t1.insertarEmpleado();
    }
}
