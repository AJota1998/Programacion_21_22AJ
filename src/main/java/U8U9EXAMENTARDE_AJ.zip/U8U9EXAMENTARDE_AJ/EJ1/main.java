package U8U9EXAMENTARDE_AJ.EJ1;

public class main {
    public static void main(String[] args) {

        ModificacionDOM.parseDOM();

        ModificacionDOM.addPiloto();

        ModificacionDOM.insertarPaisOrigen();

        ModificacionDOM.guardarEnFichero();
    }
}
