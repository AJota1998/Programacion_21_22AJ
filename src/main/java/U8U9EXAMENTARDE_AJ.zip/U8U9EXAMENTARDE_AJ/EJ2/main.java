package U8U9EXAMENTARDE_AJ.EJ2;

public class main {
    public static void main(String[] args) {

       RecorridoSTAX rStax1 = new RecorridoSTAX();

       rStax1.pilotomascampeonatos();
       rStax1.numPilotosEscuderia();

    }
}
