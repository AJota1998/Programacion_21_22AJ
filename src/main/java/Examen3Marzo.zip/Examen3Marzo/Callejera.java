package Examen3Marzo;

public interface Callejera {

    public void amo_a_escuchar();
}
